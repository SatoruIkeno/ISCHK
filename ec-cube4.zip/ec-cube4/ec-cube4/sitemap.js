Evergage.init({
    account: "imjcorp",
    dataset: "sfdc",
    trackerUrl: "https://imjcorp.evergage.com",
    cookieDomain: "is-demo.herokuapp.com"
}).then(() => {
   
    //Create site-map here.
    // When starting the lab, only copy the code below this point. The code above has already been configured for your specific account.
        
    const config = {
        global: {
            //locale: () => {},
            // listeners: [
            //     //Global Listener
            // ],
            // onActionEvent: (actionEvent) => {
            //     //Global Action Event
            //     return actionEvent;
            // },
            contentZones: [
                {name: "infobar", selector: ".infobar"}
            ]
        },
        pageTypes: []
    };

    //PDP - Caputure Product Data & Demensions
    config.pageTypes.push({
        name: "Product_Detail",
        action: "Product_Detail",
        isMatch: () => {
            return /\/products\/detail\//.test(window.location.pathname);
        },
        catalog: {
            Product: {
                _id: Evergage.resolvers.fromSelectorAttribute("#product_id", "value"),
                name: Evergage.resolvers.fromSelector(".ec-headingTitle"),
                description: Evergage.resolvers.fromSelector(".ec-productRole__description"),
                url: Evergage.resolvers.fromHref(),
                imageUrl: Evergage.resolvers.fromSelectorAttribute(".slide-item img", "src"),
                price: Evergage.resolvers.fromSelector(".ec-price__price"),
                categories: Evergage.resolvers.buildCategoryIdAttribute(".ec-productRole__category ul li a", "title", null, null, (categoryId) => [categoryId]),
                dimensions: {
                    Features: Evergage.resolvers.fromSelectorMultiple(".ec-productRole__tags .ec-productRole__tag", (features) => {
                        return features.map((feature) => {
                            return feature.trim();
                        });
                    })
                }
            }
        },
        contentZones: [
            { name: "product_detail_recs_row", selector: ".is-productsReccomendRole"},
        ],
        //sendEvent itemAction Favorite, AddToCart
        listeners: [
            Evergage.listener("click", "#favorite", () => {
                Evergage.sendEvent({
                    itemAction: Evergage.ItemAction.Favorite,
                    catalog: {
                        Product: {
                            _id: Evergage.cashDom("#product_id").attr("value"),
                            name: Evergage.cashDom(".ec-headingTitle").text()
                        }
                    }
                });
            }),
            Evergage.listener("click", ".add-cart", () => {
                const lineItem = Evergage.util.buildLineItemFromPageState("input[id*=quantity]");
                lineItem.sku = { _id: Evergage.cashDom("#product_id").attr("value")};
                Evergage.sendEvent({
                    itemAction: Evergage.ItemAction.AddToCart,
                    cart: {
                        singleLine: {
                            Product: lineItem
                        }
                    }
                });
            })
        ],

    });

    //CLP - Caputure Category Data 
    config.pageTypes.push({
        name: "Category",
        action: "Category",
        isMatch: () => {
            return /\/products\/list/.test(window.location.pathname);
        },
        catalog: {
            Category: {
                _id: Evergage.resolvers.fromSelectorAttribute(".ec-topicpath__item--active a", "title"),
                name: Evergage.resolvers.fromSelector(".ec-topicpath__item--active a"),
                url: Evergage.resolvers.fromHref()
            }
        } 
    });

    //Login Action
    config.pageTypes.push({
        name: "Login",
        action: "Login",
        isMatch: () => /\/mypage\/login/.test(window.location.href),
        listeners: [
            Evergage.listener("click", "form[name='login_mypage'] button", () => {
                const email = Evergage.cashDom("#login_email").val();
                if (email) {
                    Evergage.sendEvent({
                        action: "Logged In", 
                        user: {
                            id: email
                        } 
                    });
                }
            }),
        ]
    });

    //My Page - Caputure UserAttributes
    config.pageTypes.push({
        name: "Mypage",
        action: "Mypage",
        isMatch: () => /\/mypage\/$/.test(window.location.href),
        onActionEvent: (actionEvent) => {
            if (actionEvent.action === "Mypage") {
                const firstName = Evergage.cashDom("span.firstname").text();
                const lastName = Evergage.cashDom("span.lastname").text();
                const point = Evergage.cashDom("span.point").text() > 0 ? Evergage.cashDom("span.point").text() : 0;
                Evergage.sendEvent({
                    user: {
                        attributes:{
                            firstName:firstName, 
                            lastName:lastName, 
                            point:point
                        }
                    }
                });
            }
            return actionEvent;
        }
    });

    //Purchase
    config.pageTypes.push({
        name: "Purchase",
        action: "Purchase",
        isMatch: () => /\/shopping\/complete/.test(window.location.href),
        onActionEvent: (actionEvent) => {
            if (actionEvent.action === "Purchase") {  
                var selectedElements = Evergage.cashDom("p.lineitem");
                var lineItems = selectedElements.get().map(function (elem) {
                    return {
                        "_id":Evergage.cashDom(elem).data("pid"),
                        "price":Evergage.cashDom(elem).data("price"),
                        "quantity":Evergage.cashDom(elem).data("quantity"),
                    }
                });
                Evergage.sendEvent({
                    itemAction: Evergage.ItemAction.Purchase,
                    order: {
                        Product: {
                            orderId: Evergage.cashDom(".orderId").text(),
                            lineItems: lineItems
                        }
                    }
                });
            }
            return actionEvent;
        }
    });

    config.pageTypes.push({
        name: "Homepage",
        action: "Homepage",
        isMatch: () => {
            return /\/$/.test(window.location.pathname);
        },
        contentZones: [
            {name: "Homepage | Hero", selector: ".ec-sliderRole"}
        ]
    });

    Evergage.initSitemap(config);

});